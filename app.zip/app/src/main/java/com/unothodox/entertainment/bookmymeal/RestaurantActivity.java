package com.unothodox.entertainment.bookmymeal;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

public class RestaurantActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant);

        //SharedPreferences preferences =
                this.getSharedPreferences(
                getString(R.string.shared_preferences),
                Context.MODE_PRIVATE);
        /*SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(getString(R.string.preference_meat), true);
        editor.apply();*/

        DBClass myDB = new DBClass(this);

        RecyclerView rv_restaurants =
                findViewById(R.id.rv_restaurants);

        RecyclerView.LayoutManager layoutManager =
                new GridLayoutManager(this, 2);
        RecyclerView.Adapter adapter =
                new RestaurantAdapter(myDB.getRestaurantNames());
        rv_restaurants.setLayoutManager(layoutManager);
        rv_restaurants.setAdapter(adapter);
    }

    public void toCart(View view)   {
        if (view.getId() == R.id.b_cart)    {
            Intent i = new Intent(this, CartActivity.class);
            startActivity(i);
        }
    }

    public void toOrders(View view) {
        if (view.getId() == R.id.b_prev)    {
            Intent i = new Intent(this, OrdersActivity.class);
            startActivity(i);
        }
    }
}
