package com.unothodox.entertainment.bookmymeal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBClass extends SQLiteOpenHelper {

    private static final String DBName = "BookMyMealDB";
    private static final String table_01 = "LIST_REST";
    private static final String table_02 = "LIST_ITEMS";
    private static final String table_03 = "PRES_ORDER";
    private static final String table_04 = "LIST_ADDRESS";
    private static final String table_05 = "LIST_ORDERS";

    DBClass(Context context) {
        super(context, DBName, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String create_table_01 = "CREATE TABLE " + table_01 +
                " ( ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                " NAME TEXT)";
        sqLiteDatabase.execSQL(create_table_01);

        ContentValues cv = new ContentValues();
        cv.put("NAME", "Dine with Me");
        sqLiteDatabase.insert(table_01, null, cv);

        cv.put("NAME", "Elephant Restaurant");
        sqLiteDatabase.insert(table_01, null, cv);

        cv.put("NAME", "Alpha Hotel International");
        sqLiteDatabase.insert(table_01, null, cv);

        cv.put("NAME", "Babai Hotel pure VEG");
        sqLiteDatabase.insert(table_01, null, cv);

        cv.put("NAME", "Vegetables & Fruits");
        sqLiteDatabase.insert(table_01, null, cv);


        String create_table_restaurant_01 = "CREATE TABLE " + table_02 +
                " ( ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                " REST INTEGER," +
                " NAME TEXT," +
                " MEAT INTEGER," +
                " PRICE INTEGER," +
                " FOREIGN KEY (REST)" +
                " REFERENCES " + table_01 + " (ID))";
        sqLiteDatabase.execSQL(create_table_restaurant_01);

        //DWM
        cv.put("REST", "1");
        cv.put("NAME", "Plain Naan");
        cv.put("MEAT", 0);
        cv.put("PRICE", 20);
        sqLiteDatabase.insert(table_02, null, cv);
        cv.put("REST", "1");
        cv.put("NAME", "Butter Naan");
        cv.put("MEAT", 0);
        cv.put("PRICE", 25);
        sqLiteDatabase.insert(table_02, null, cv);
        cv.put("REST", "1");
        cv.put("NAME", "Paneer Curry");
        cv.put("MEAT", 0);
        cv.put("PRICE", 100);
        sqLiteDatabase.insert(table_02, null, cv);
        cv.put("REST", "1");
        cv.put("NAME", "Chicken Curry");
        cv.put("MEAT", 1);
        cv.put("PRICE", 200);
        sqLiteDatabase.insert(table_02, null, cv);

        //Elephant
        cv.put("REST", "2");
        cv.put("NAME", "Veg. Biriyani");
        cv.put("MEAT", 0);
        cv.put("PRICE", 100);
        sqLiteDatabase.insert(table_02, null, cv);
        cv.put("REST", "2");
        cv.put("NAME", "Paneer Biriyani");
        cv.put("MEAT", 0);
        cv.put("PRICE", 120);
        sqLiteDatabase.insert(table_02, null, cv);
        cv.put("REST", "2");
        cv.put("NAME", "Chicken Biriyani");
        cv.put("MEAT", 1);
        cv.put("PRICE", 150);
        sqLiteDatabase.insert(table_02, null, cv);
        cv.put("REST", "2");
        cv.put("NAME", "Mutton Biriyani");
        cv.put("MEAT", 1);
        cv.put("PRICE", 200);
        sqLiteDatabase.insert(table_02, null, cv);

        //Alpha
        cv.put("REST", "3");
        cv.put("NAME", "Veg. Fried Rice");
        cv.put("MEAT", 0);
        cv.put("PRICE", 150);
        sqLiteDatabase.insert(table_02, null, cv);
        cv.put("REST", "3");
        cv.put("NAME", "Chicken Fried Rice");
        cv.put("MEAT", 1);
        cv.put("PRICE", 200);
        sqLiteDatabase.insert(table_02, null, cv);
        cv.put("REST", "3");
        cv.put("NAME", "Onion Samosa");
        cv.put("MEAT", 0);
        cv.put("PRICE", 20);
        sqLiteDatabase.insert(table_02, null, cv);
        cv.put("REST", "3");
        cv.put("NAME", "Corn Samosa");
        cv.put("MEAT", 0);
        cv.put("PRICE", 25);
        sqLiteDatabase.insert(table_02, null, cv);

        //Babai
        cv.put("REST", "4");
        cv.put("NAME", "Idli");
        cv.put("MEAT", 0);
        cv.put("PRICE", 20);
        sqLiteDatabase.insert(table_02, null, cv);
        cv.put("REST", "4");
        cv.put("NAME", "Dosa");
        cv.put("MEAT", 0);
        cv.put("PRICE", 25);
        sqLiteDatabase.insert(table_02, null, cv);
        cv.put("REST", "4");
        cv.put("NAME", "Puri");
        cv.put("MEAT", 0);
        cv.put("PRICE", 20);
        sqLiteDatabase.insert(table_02, null, cv);
        cv.put("REST", "4");
        cv.put("NAME", "Vada");
        cv.put("MEAT", 0);
        cv.put("PRICE", 20);
        sqLiteDatabase.insert(table_02, null, cv);

        //V&F
        cv.put("REST", "5");
        cv.put("NAME", "Fruit Salad");
        cv.put("MEAT", 0);
        cv.put("PRICE", 50);
        sqLiteDatabase.insert(table_02, null, cv);
        cv.put("REST", "5");
        cv.put("NAME", "Mixed Vegetable Breakfast");
        cv.put("MEAT", 0);
        cv.put("PRICE", 75);
        sqLiteDatabase.insert(table_02, null, cv);
        cv.put("REST", "5");
        cv.put("NAME", "Vanilla Ice Cream");
        cv.put("MEAT", 0);
        cv.put("PRICE", 30);
        sqLiteDatabase.insert(table_02, null, cv);
        cv.put("REST", "5");
        cv.put("NAME", "Butterscotch Ice Cream");
        cv.put("MEAT", 0);
        cv.put("PRICE", 40);
        sqLiteDatabase.insert(table_02, null, cv);

        String create_table_03 = "CREATE TABLE " + table_03 +
                " ( ITEM INTEGER," +
                " COUNT INTEGER, " +
                " FOREIGN KEY (ITEM)" +
                " REFERENCES " + table_02 + "(ID))";
        sqLiteDatabase.execSQL(create_table_03);

        String create_table_04 = "CREATE TABLE " + table_04 +
                " ( ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                " ADDRESS TEXT)";
        sqLiteDatabase.execSQL(create_table_04);

        String create_table_05 = "CREATE TABLE " + table_05 +
                " ( ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                " ITEMS TEXT)";
        sqLiteDatabase.execSQL(create_table_05);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    ArrayList<String> getRestaurantNames()  {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                table_01,
                new String[] {"NAME"},
                null,
                null,
                null,
                null,
                null);

        ArrayList<String> e = new ArrayList<>();
        while(cursor.moveToNext())  {
            e.add(cursor.getString(0));
        }
        cursor.close();

        return e;
    }

    String getRest(int id)  {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                table_01,
                new String[] {"NAME"},
                "ID =?",
                new String[] {String.valueOf(id)},
                null,
                null,
                null);

        String restaurant = "";
        if(cursor.moveToNext())  {
            restaurant = cursor.getString(0);
        }
        cursor.close();
        return restaurant;
    }

    ArrayList<MenuItem> getMenu(int restaurant)  {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                table_02,
                new String[] {"ID", "NAME", "MEAT", "PRICE"},
                "REST =? ",
                new String[] {String.valueOf(restaurant)},
                null,
                null,
                null);

        ArrayList<MenuItem> e = new ArrayList<>();
        while(cursor.moveToNext())  {
            e.add(new MenuItem(cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getInt(2),
                    cursor.getInt(3)));
        }
        cursor.close();

        return e;
    }

    ArrayList<MenuItem> getVegMenu(int restaurant)  {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                table_02,
                new String[] {"ID", "NAME", "MEAT", "PRICE"},
                "REST =? AND MEAT =? ",
                new String[] {String.valueOf(restaurant), "0"},
                null,
                null,
                null);

        ArrayList<MenuItem> e = new ArrayList<>();
        while(cursor.moveToNext())  {
            e.add(new MenuItem(cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getInt(2),
                    cursor.getInt(3)));
        }
        cursor.close();

        return e;
    }

    class MenuItem  {
        int id, rest;
        String name;
        boolean meat;
        int price;

        public MenuItem(int id, String name, int meat, int price) {
            this.id = id;
            this.name = name;
            this.meat = meat == 1;
            this.price = price;
        }

        public MenuItem(String name, int rest, int meat, int price)  {
            this.name = name;
            this.rest = rest;
            this.meat = meat == 1;
            this.price = price;
        }
    }

    MenuItem getMenuItem(int id)  {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                table_02,
                new String[] {"NAME", "REST", "MEAT", "PRICE"},
                "ID =? ",
                new String[] {String.valueOf(id)},
                null,
                null,
                null);

        MenuItem e = null;
        if(cursor.moveToNext())  {
            e = new MenuItem(cursor.getString(0),
                    cursor.getInt(1),
                    cursor.getInt(2),
                    cursor.getInt(3));
        }
        cursor.close();
        return e;
    }

    int getCount(int item)   {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                table_03,
                new String[] {"COUNT"},
                "ITEM =?",
                new String[] {String.valueOf(item)},
                null,
                null,
                null);

        int ret = 0;
        if (cursor.moveToNext())
            ret = cursor.getInt(0);
        cursor.close();
        return ret;
    }

    void placeOrder(int item, int count)    {
        SQLiteDatabase db = this.getReadableDatabase();

        if (getCount(item) == 0 && count != 0) {
            ContentValues cv = new ContentValues();
            cv.put("ITEM", item);
            cv.put("COUNT", count);
            db.insert(table_03, null, cv);

        }else   {
            if (count == 0)
                db.delete(table_03, "ITEM =? ", new String[] {String.valueOf(item)});

            else    {
                ContentValues cv = new ContentValues();
                cv.put("COUNT", count);
                db.update(table_03, cv, "ITEM =? ", new String[] {String.valueOf(item)});
            }
        }
    }

    class CartItem  {
        int item;
        int count;

        CartItem(int item, int count) {
            this.item = item;
            this.count = count;
        }
    }

    ArrayList<CartItem> getPresOrder()  {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                table_03,
                new String[] {"ITEM", "COUNT"},
                null,
                null,
                null,
                null,
                null);

        ArrayList<CartItem> e = new ArrayList<>();
        while(cursor.moveToNext())
            e.add(new CartItem(cursor.getInt(0), cursor.getInt(1)));

        cursor.close();
        return e;
    }

    ArrayList<String> getAddresses()  {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                table_04,
                new String[] {"ADDRESS"},
                null,
                null,
                null,
                null,
                null);

        ArrayList<String> e = new ArrayList<>();
        while(cursor.moveToNext())  {
            e.add(cursor.getString(0));
        }
        cursor.close();

        return e;
    }

    void addAddress(String address) {
        SQLiteDatabase db = this.getReadableDatabase();

        ContentValues cv = new ContentValues();
        cv.put("ADDRESS", address);
        db.insert(table_04, null, cv);
    }

    void addOrder(ArrayList<CartItem> e)    {
        SQLiteDatabase db = this.getReadableDatabase();

        StringBuilder s = new StringBuilder();
        for (CartItem ci : e) {
            s.append(ci.item)
                    .append("x")
                    .append(ci.count)
                    .append(",");
        }

        ContentValues cv = new ContentValues();
        cv.put("ITEMS", s.toString());
        db.insert(table_05, null, cv);
    }

    ArrayList<String> getOrders()  {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                table_05,
                new String[] {"ITEMS"},
                null,
                null,
                null,
                null,
                null);

        ArrayList<String> e = new ArrayList<>();
        while(cursor.moveToNext())  {
            e.add(cursor.getString(0));
        }
        cursor.close();

        return e;
    }

    void emptyCart()    {
        SQLiteDatabase db = this.getReadableDatabase();

        String delete_from_table = "DELETE FROM " + table_03;
        db.execSQL(delete_from_table);
    }
}
