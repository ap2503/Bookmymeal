package com.unothodox.entertainment.bookmymeal;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

import java.util.ArrayList;

public class MenuActivity extends AppCompatActivity {

    private RecyclerView.Adapter adapter;
    private ArrayList<DBClass.MenuItem> e, e_all, e_veg;
    private DBClass myDB;
    private int ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        myDB = new DBClass(this);

        RecyclerView rv_menu = findViewById(R.id.rv_menu);

        ID = getIntent().getIntExtra("ID", 0);
        e_all = myDB.getMenu(ID);
        e_veg = myDB.getVegMenu(ID);

        SharedPreferences preferences = this.getSharedPreferences(getString(R.string.shared_preferences),
                Context.MODE_PRIVATE);
        boolean isMeat = preferences.getBoolean(getString(R.string.preference_meat), true);


        e = isMeat? e_all : e_veg;

        RecyclerView.LayoutManager layoutManager =
                new LinearLayoutManager(this);
        adapter = new MenuAdapter(this, e);
        rv_menu.setLayoutManager(layoutManager);
        rv_menu.setAdapter(adapter);
    }

    public void toCart(View view)   {
        if (view.getId() == R.id.b_next)    {
            Intent i = new Intent(this, CartActivity.class);
            startActivityForResult(i, 23);
        }
    }

    public void filter(View view)   {
        if (view.getId() == R.id.b_filter)  {
            final SharedPreferences preferences =
                    this.getSharedPreferences(
                            getString(R.string.shared_preferences),
                            Context.MODE_PRIVATE);
            final boolean[] meat = {preferences.getBoolean(getString(R.string.preference_meat), true)};

            AlertDialog.Builder builder = new AlertDialog.Builder(MenuActivity.this);
            builder.setTitle("Choice of Food")
                    .setSingleChoiceItems(getResources().getStringArray(R.array.meat_options), (meat[0])? 1 : 0,
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    meat[0] = i == 1;
                                }
                            })
                    .setPositiveButton("FILTER", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            SharedPreferences.Editor editor = preferences.edit();
                            editor.putBoolean(getString(R.string.preference_meat), meat[0]);
                            editor.apply();

                            e.clear();
                            if (meat[0])
                                e.addAll (e_all);
                            else
                                e.addAll(e_veg);
                            Log.d("abx", String.valueOf(meat[0]));
                            adapter.notifyDataSetChanged();
                        }
                    });
            builder.create().show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if  (resultCode == RESULT_CANCELED && requestCode == 23)  {
            e.clear();
            e.addAll(myDB.getMenu(ID));
            adapter.notifyDataSetChanged();
        }
    }
}
