package com.unothodox.entertainment.bookmymeal;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.MyViewHolder> {
    private Context context;
    private DBClass myDB;
    private ArrayList<String> orders;

    OrderAdapter(Context context, ArrayList<String> e) {
        this.orders = e;
        this.context = context;
        myDB = new DBClass(context);
    }

    static class MyViewHolder extends RecyclerView.ViewHolder   {
        TextView tv_order;

        MyViewHolder(TextView tv_order) {
            super(tv_order);
            this.tv_order = tv_order;
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder((TextView) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_order, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, int position) {
        String order = orders.get(position);
        String[] items = order.split(",");
        String[] kvp = items[0].split("x");

        DBClass.MenuItem mi = myDB.getMenuItem(Integer.valueOf(kvp[0]));
        String final_string = mi.name + " -> " + kvp[1] + "...";

        holder.tv_order.setText(final_string);
    }

    @Override
    public int getItemCount() {
        return orders.size();
    }

}
