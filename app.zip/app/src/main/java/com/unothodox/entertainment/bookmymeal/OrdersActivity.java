package com.unothodox.entertainment.bookmymeal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class OrdersActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders);

        DBClass myDB = new DBClass(this);
        RecyclerView rv_orders = findViewById(R.id.rv_orders);

        ArrayList<String> all_orders = myDB.getOrders();

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        rv_orders.setLayoutManager(layoutManager);
        RecyclerView.Adapter adapter = new OrderAdapter(this, all_orders);
        rv_orders.setAdapter(adapter);
    }
}
