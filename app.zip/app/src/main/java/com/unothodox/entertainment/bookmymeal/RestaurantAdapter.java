package com.unothodox.entertainment.bookmymeal;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

class RestaurantAdapter extends
        RecyclerView.Adapter<RestaurantAdapter.MyViewHolder> {
    private ArrayList<String> restaurants;

    RestaurantAdapter(ArrayList<String> e) {
        this.restaurants = e;
    }

    static class MyViewHolder extends RecyclerView.ViewHolder  {
        TextView tv_name;

        MyViewHolder(View view) {
            super(view);
            this.tv_name = view.findViewById(R.id.tv_name);
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_restaurants,
                        parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        holder.tv_name.setText(restaurants.get(position));

        holder.tv_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(holder.tv_name.getContext(), MenuActivity.class);
                i.putExtra("ID", holder.getAdapterPosition()+1);
                holder.tv_name.getContext().startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return restaurants.size();
    }

}
