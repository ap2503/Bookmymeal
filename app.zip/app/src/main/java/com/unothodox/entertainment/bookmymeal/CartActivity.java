package com.unothodox.entertainment.bookmymeal;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class CartActivity extends AppCompatActivity {

    private DBClass myDB;
    private CheckBox cb_address;
    private EditText et_address;

    private ArrayList<DBClass.CartItem> cartItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        myDB = new DBClass(this);

        RecyclerView rv_menu = findViewById(R.id.rv_cart);
        TextView tv_price = findViewById(R.id.tv_price);
        cb_address = findViewById(R.id.cb_address);
        et_address = findViewById(R.id.et_address);

        cb_address.setEnabled(false);

        cartItems = myDB.getPresOrder();
        //todo - put this above the set contentView for items.num == 0

        RecyclerView.LayoutManager layoutManager =
                new LinearLayoutManager(this);
        RecyclerView.Adapter adapter = new CartAdapter(this, cartItems);
        rv_menu.setLayoutManager(layoutManager);
        rv_menu.setAdapter(adapter);

        int total_price = 0;
        for (DBClass.CartItem ci : cartItems)   {
            total_price += myDB.getMenuItem(ci.item).price * ci.count;
        }
        tv_price.setText(String.valueOf(total_price));

        et_address.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (b)  {
                    cb_address.setEnabled(true);
                }
            }
        });
    }

    public void usePrev(View view) {
        if (view.getId() == R.id.b_use_prev) {
            ArrayList<String> addresses = myDB.getAddresses();
            final CharSequence[] addressArray = addresses.toArray(new CharSequence[0]);

            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            if (addressArray.length == 0)  {
                builder.setMessage("There are no previous addresses.");

            }else   {
                builder.setTitle("Previous Addresses")
                        .setItems(addressArray, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                et_address.setText(addressArray[i]);
                                cb_address.setEnabled(false);
                            }
                        });
            }
            builder.create().show();
        }

    }

    public void placeOrder(View view)   {
        if (view.getId() == R.id.b_order)   {

            AlertDialog.Builder builder = new AlertDialog.Builder(CartActivity.this);
            builder.setMessage("Are you sure about the contents of the order?")
                    .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                            if  (cb_address.isChecked())
                                myDB.addAddress(et_address.getText().toString());
                            if (cartItems.size() != 0)
                                myDB.addOrder(cartItems);
                            myDB.emptyCart();
                            finish();
                        }
                    });
            builder.create().show();
            //todo - go to dialog and then to next activity.
        }
    }

    public void emptyCart(View view)    {
        if (view.getId() == R.id.tv_empty_cart) {

            AlertDialog.Builder builder = new AlertDialog.Builder(CartActivity.this);
            builder.setTitle("Empty Cart?")
                    .setMessage("All the saved items will be lost.")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            myDB.emptyCart();
                            finish();
                        }
                    });
            builder.create().show();
        }
    }
}
