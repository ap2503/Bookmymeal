package com.unothodox.entertainment.bookmymeal;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

class CartAdapter extends RecyclerView.Adapter<CartAdapter.MyViewHolder> {
        private Context context;
        private DBClass myDB;
        private ArrayList<DBClass.CartItem> items;

    CartAdapter(Context context, ArrayList<DBClass.CartItem> items) {
        this.items = items;
        this.context = context;
        myDB = new DBClass(context);
    }

    static class MyViewHolder extends RecyclerView.ViewHolder   {
        TextView tv_item, tv_rest, tv_price, tv_count, tv_net_price;

        MyViewHolder(View view) {
            super(view);
            tv_item = view.findViewById(R.id.tv_item);
            tv_rest = view.findViewById(R.id.tv_rest);
            tv_price = view.findViewById(R.id.tv_price);
            tv_count = view.findViewById(R.id.tv_count);
            tv_net_price = view.findViewById(R.id.tv_net_price);
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_cart, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        DBClass.MenuItem mi = myDB.getMenuItem(items.get(position).item);
        holder.tv_item.setText(mi.name);
        holder.tv_rest.setText(myDB.getRest(mi.rest));
        holder.tv_price.setText(String.valueOf(mi.price));
        holder.tv_count.setText(String.valueOf(items.get(position).count));
        holder.tv_net_price.setText(String.valueOf(mi.price * items.get(position).count));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
