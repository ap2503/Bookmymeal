package com.unothodox.entertainment.bookmymeal;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.TextView;

import java.util.ArrayList;

class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.MyViewHolder> {
    private Context context;
    private DBClass myDB;
    private ArrayList<DBClass.MenuItem> items;

    MenuAdapter(Context context, ArrayList<DBClass.MenuItem> e) {
        this.items = e;
        this.context = context;
        myDB = new DBClass(context);
    }

    static class MyViewHolder extends RecyclerView.ViewHolder   {
        View v_meat;
        TextView tv_item, tv_price, tv_count;
        Button b_add;

        MyViewHolder(View view) {
            super(view);
            this.v_meat = view.findViewById(R.id.v_meat);
            this.tv_item = view.findViewById(R.id.tv_item);
            this.tv_price = view.findViewById(R.id.tv_price);
            this.b_add = view.findViewById(R.id.b_add);
            this.tv_count = view.findViewById(R.id.tv_count);
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == 0) {
            return new MyViewHolder(LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.layout_menu, parent, false));
        }
        else    {
            return new MyViewHolder(LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.layout_menu_selected, parent, false));
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (myDB.getCount(items.get(position).id) > 0)
            return 1;
        else
            return 0;
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        final DBClass.MenuItem mi = items.get(position);

        holder.tv_item.setText(mi.name);
        holder.tv_price.setText(String.valueOf(mi.price));

        if (mi.meat)
            holder.v_meat.setBackgroundResource(R.color.meat);
        else
            holder.v_meat.setBackgroundResource(R.color.non_meat);

        final int count = myDB.getCount(items.get(position).id);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final NumberPicker np_count = (NumberPicker) View.inflate(context,
                        R.layout.dialog_count, null);
                np_count.setMinValue(0);
                np_count.setMaxValue(10);
                np_count.setValue(count);
                np_count.setWrapSelectorWheel(false);

                AlertDialog.Builder builder =
                        new AlertDialog.Builder(context);
                builder.setTitle("Select number of items.")
                        .setView(np_count)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                myDB.placeOrder(mi.id, np_count.getValue());
                                notifyItemChanged(holder.getAdapterPosition());
                            }
                        });

                builder.create().show();
            }
        };

        if (count > 0) {
            holder.tv_count.setText(String.valueOf(count));
            holder.tv_count.setOnClickListener(listener);

        }else {
            holder.b_add.setOnClickListener(listener);
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

}
